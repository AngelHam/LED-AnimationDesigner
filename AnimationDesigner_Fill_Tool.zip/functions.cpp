#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
#include <limits>
#include "functions.h"
#undef max

using namespace std;

bool loadedFile = false; 

// You should not modify this function. //
void printMenu() {
  cout << "--------------------------" << endl;
  cout << " 'L': Load Text File" << endl;
  cout << " 'N': New Text File" << endl;
  cout << " 'A': Output Add Color" << endl;
  cout << " 'H': Help/Guide" << endl;
  cout << " 'Q': Quit" << endl;
  cout << "--------------------------" << endl;
  cout << endl << "Please enter your choice: ";
}

void processHelp() {
	cout << "This program was created to help design .txt animation files for the ";
	cout << "LED-AnimationDesigner created by Nicholas Deory, in support of the leagueoflegends-led GitHub project. ";
	cout << "To import these text files and use the Animation Designer tool, or to download the led program, please visit the following links: " << endl;
	cout << "Animation Designer GitHub: https://github.com/nicolasdeory/LED-AnimationDesigner" << endl;
	cout << "Leagueoflegends-led GitHub: https://github.com/nicolasdeory/leagueoflegends-led" << endl << endl;
	cout << "Program Features:" << endl << endl;
	cout << "Load Text File:" << endl; 
	cout << "Place an existing .txt file made using this program or the LED-AnimationDesigner ";
	cout << "into the same folder of this program, then run this function to load in the text file to edit. " << endl << endl;
	cout << "New Text File: " << endl;
	cout << "Creates a new .txt file that can be imported into the LED-AnimationDesigner website. ";
	cout << "Allows you to specify the number of frames for the file." << endl << endl;
	cout << "Output Add Color:" << endl;
	cout << "After creating a new text file or loading one in, allows user to fill in rows of colors for devices as well as specify which frames the colors will be put on." << endl << endl;
	cout << "Help/Guide: " << endl;
	cout << "Brings up this menu." << endl << endl;
	cout << "Quit:" << endl;
	cout << "Exits the program."  << endl << endl;
	cout << "For questions, bug-concerns, and comments, please reach out to my Discord, 'GrandPaladin' on the League Lights Discord server. This program was made by Angel Ham and last updated May 21, 2020. " << endl; 
}

string getFilename(string prompt) {
  string filename;
  cout << prompt << ": ";
  cin >> filename;
  return filename;
}

unsigned int getColorValue(string prompt) {
  unsigned int val;
  do {
    cout << prompt;
    cin >> val;
    if (cin.fail()) {
      cout << " -- invalid color value" << endl;
      cin.clear(); // reset stream states
      cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear buffer    
      val = 300;
    }
    else if (val > 255) {
      cout << " -- color value must be between 0 and 255" << endl;
    }
  } while (val > 255);
  return val;
}

Pixel getPixel() {
  int r, g, b;
  cout << "Enter RGB Color Values (0-255):" << endl;
  cout << "This is a helpful site to pick RGB values: https://www.rapidtables.com/web/color/RGB_Color.html" << endl;
  r = getColorValue(" - Red: ");
  g = getColorValue(" - Green: ");
  b = getColorValue(" - Blue: ");
  if (b > 0) {
		cout << "'WARNING: Due to a known bug, the last key on the last row of devices will not load colors with a Blue RGB value when trying to import to the webiste, therefore it will be ommitted when making this text file" << endl;
	}
  return Pixel(r, g, b);
}
  
void getBounds(Image& image, int bounds[4]) {
	int startCol, endCol, startRow, endRow;
	cout << "LIST OF INPUTS FOR ALL DEVICES: " << endl;
	cout << "Legend: [ 'Key1'->'Key2': inputValue#1 - inputValue#2 ]" << endl;
	cout << endl;
	cout << "Keyboard Rows: " << endl;
	cout << "[ Esc->PauseBreak: 0 - 16 ]" << endl;
	cout << "[ Tilde->PgUp: 16 - 33 ]" << endl;
	cout << "[ Tab->PgDown: 33 - 50 ]" << endl; 
	cout << "[ CapsLock->Enter: 50 - 63 ]" << endl;
	cout << "[ Shift->UpArrow: 63 - 77 ]" << endl;
	cout << "[ Ctrl->RightArrow: 77 - 88 ]" << endl << endl;
	cout << "Keyboard Continued, Numpad Rows: " << endl;
	cout << "[ m1-m4: 88 - 92 ]" << endl;
	cout << "[ NumLk->'-': 92 - 96 ]" << endl;
	cout << "[ '7'->'+': 96 - 100 ]" << endl;
	cout << "[ '4'->'6': 100 - 103 ]" << endl;
	cout << "[ '1'->Enter: 103 - 107 ]" << endl;
	cout << "[ '0'->'.': 107 - 109 ]"  << endl << endl;
	cout << "LED Strip Rows: " << endl;
	cout << "[ First Half of Row: 109 - 194 ]" << endl;
	cout << "[ Entire Row: 109 - 279 ]" << endl << endl;
	cout << "Mouse: " << endl;
	cout << "[ 'Logo': 279 - 279 ]" << endl;
	cout << "[ 'Scroll': 280 - 280]" << endl;
	cout << "[ 'Entire Mouse': 279 - 295]" << endl << endl;
	cout << "Mousepad: " << endl;
	cout << "[ 'LEDs on Left side of Mousepad': 295 - 303]" << endl;
	cout << "[ 'LEDs on Left side of Mousepad': 303 - 311]" << endl;
	cout << "[ 'All LEDs from Left to Right': 295 - 311]" << endl << endl;
	cout << "Headset: " << endl;
	cout << "[ 'Left LED Headset': 311 - 312]" << endl;
	cout << "[ 'Right LED Headset': 312 - 313]" << endl;
	cout << "[ 'Entire Headset': 311 - 313]" << endl << endl;
	cout << "Keypad: " << endl;
	cout << "[ '01'->'05': 313 - 318]" << endl;	
	cout << "[ '06'->'10': 318 - 323]" << endl;	
	cout << "[ '11'->'15': 323 - 328]" << endl;	
	cout << "[ '16'->'20': 328 - 333]" << endl;	
	cout << "[ 'Entire Keypad': 313 - 333]" << endl << endl;	
	cout << "General LEDs (From Left to Right): " << endl;
	cout << "[ 'MainColor'->'SEC-4': 333 - 338]" << endl << endl;
	cout << "All Keys on All Devices: " << endl;
	cout << "[ 0 - 338 ]" << endl << endl;
	cout << "Enter a set of keys to be colored (Leftmost Key -> Rightmost Key) " << endl;
	cout << "(Example input: '0 16' : 0-16 is first row on device: Keyboard): "; 
	cin >> startCol >> endCol;
	while (startCol < 0 || endCol < 0 || startCol > endCol || cin.fail()) {
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		cout << "Please enter a RANGE of keys (Example: '33 50' selects Tab->PgDown row on keyboard)" << endl;
		cin >> startCol >> endCol;
	}
	bounds[0] = startCol;
	bounds[1] = endCol;
	cout << endl;
	cout << "Enter the set of frames you want to be affected, (Total Current Frames: " << image.getFrameCount() << "): " << endl;
	cout << "(Example input: '1 2' : affects frames 1 through 2 inclusively)" << endl;
	cout << "(Example input: '1 1' : affects only the 1st frame): ";
	cin >> startRow >> endRow;
	while (startRow <= 0 || startRow > image.getFrameCount() || cin.fail() ||
		endRow <= 0 || startRow > endRow || endRow > image.getFrameCount() ) {
		if (startRow == 0) {
			cout << "There cannot be a '0'th frame" << endl;
		}
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		cout << "Please enter a Starting-Ending frame selection that is positive, both are integers, and is INCLUSIVE,  (Example: input '1 1' selects from frame: [1->1] to be colored, aka only the first frame)" << endl;
		cin >> startRow >> endRow;
	}
	bounds[2] = startRow;
	bounds[3] = endRow;
	cout << endl;
}

void processAdd(const Image& image) {
  if (loadedFile != true) {
	cout << "You must load or create a text file first!" << endl;
	return;
  }
  Image addImage; 
  addImage = image;
  int bounds[4];
  bool respondYes = true;
  while (respondYes == true) {
    getBounds(addImage, bounds); // does this array get passed right?
    addImage.fillColor(getPixel(),bounds[0],bounds[1],bounds[2],bounds[3]);
    string response;
	cout << "Do you want to continue using the fillColor funciton? (y/n)" << endl;
	cin >> response;
	(response == "y" || response == "Y") ? respondYes = true : respondYes = false;
		}
  string filename = getFilename("Enter filename to save color added image (include '.txt' at the end)");
  addImage.output(filename);
}


void processLoad(Image& image) {
  string filename = getFilename("Enter filename of image to load (Example: 'example.txt')");
  image = Image(filename);
  if (image.getFrameCount() <= 0) {
	(throw std::invalid_argument("Error [Most Likely Cause]: Invalid File Name (Is your .txt file in the same folder as this program?)"));   
  }
  else {
	cout << "Loaded image..." << endl << endl;
	}
  loadedFile = true;
}
void processNew(Image& image) {
	int frames;
	cout << "Please enter the number of frames you want (positive integer): " << endl;
	cin >> frames;
	while (frames <= 0 || cin.fail()) {
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		cout << "Please enter a POSITIVE INTEGER (Example: '1', '3', '5') for the number of frames you want in your animation text file" << endl;
		cin >> frames;
	}
	image = Image(frames);
	cout << "Loaded image..." << endl << endl;
	loadedFile = true;
}





