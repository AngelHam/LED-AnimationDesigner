#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>
#include <stdexcept>
#include "Pixel.h"
#include "LedRGBColorMaker.h"
using namespace std;
int TOTAL_LEDS = 338;
int TOTAL_DEVICES = 7;

// Private Member Functions
void Image::readInFile(string filename) {
	clear();
	cout << "Loading image..." << endl;
	ifstream ifs1(filename);
	if (!ifs1.is_open() ) {
		cout << "Error: failed to open input file " << filename << endl;
		return;
	}
	string preamble;
	int fileFormatVersion;
	int frameNum;
	string s1, s2;
	getline(ifs1,s1,',');
	getline(ifs1,s2,'\n');
	fileFormatVersion = stoi(s1);
	frameNum = stoi(s2);
	if (fileFormatVersion != 2) {
		cout << "Error: file is not using correct file Format Version (2)." << endl;
		return;
	}
	allocateImage(TOTAL_LEDS,frameNum);

	
	string device; // each device in each frame, used for stringstream
	string r,g,b; // for RGB values of the pixel
	int col = 0; // for going through each of the keys of each frame
	int row = 0; // for looping through each frame of the text file
	int semicolon_cnt = 1; //6 of these ';' in each frame, file type uses them to separate devices when looping
	
	while (!ifs1.eof()) {
		if (semicolon_cnt == TOTAL_DEVICES-1) {
			getline(ifs1, device, '\n');
		}
		else {
			getline(ifs1, device,';');
		}
		stringstream ss(device); // this represents 1 Individual FRAME, 
								//still has ';'s	
		while(!ss.eof()) {
			getline(ss,r,',');
			getline(ss,g,',');
			getline(ss,b,',');
			image[col][row].setRed(stoi(r));
			image[col][row].setGreen(stoi(g));
			image[col][row].setBlue(stoi(b));
			// cout << "Set image[" << col << "][" << row << "] " << image[col][row] << endl;
			col++;
		}
		//cout << "new device" << endl;
		semicolon_cnt++;
		if(semicolon_cnt == TOTAL_DEVICES) { // if reached last device, eat the last whitespace, std::ws
			ifs1 >> ws;
			semicolon_cnt = 1;
			col = 0;
			row++;
		}
	}
	cout << "Successfully loaded imported .txt file" << endl;
}
void Image::allocateImage(int numLEDS, int frames) {
  clear();
  if (frames >= 1) {
    this->frameCount = frames;
    this->numLEDS = numLEDS;
    image = new Pixel*[numLEDS];
    for (int col=0; col < numLEDS; ++col) {
      image[col] = new Pixel[frameCount];
    }
	Pixel p(0,0,0);
	for (int col = 0; col < numLEDS; col++) {
		for (int row = 0; row < frameCount; row++) {
			image[col][row] = p;
		}
	} 
  }
  else {
	 throw std::runtime_error("numLEDS is not equal to TOTAL_LEDS and frameCountis not >= 1");
	 }
}

void Image::clear() {
  delete [] image;
  this->frameCount = 0; this->numLEDS = 0;
  image = nullptr;
}

void Image::print() {
	for (int row = 0; row < frameCount; ++row) {
      for (int col = 0; col < TOTAL_LEDS; ++col) {
			cout << image[col][row] << ',';
		}
		cout << endl << endl << "End of row: " << row << endl << endl;
    }
	cout << endl;
	cout << "Successfully printed out image" << endl;
}

// Public Member Functions
Image::Image() : image(nullptr), numLEDS(0), frameCount(0) {}

Image::Image(std::string filename) : image(nullptr), numLEDS(0), frameCount(0) {
	readInFile(filename);
}
Image::Image(int frames) : image(nullptr), numLEDS(TOTAL_LEDS), frameCount(frames) {
	allocateImage(numLEDS, frames);
}
	

Image::Image(const Image& origImage) { //copy constructor
	this->numLEDS = origImage.numLEDS;
	this->frameCount = origImage.frameCount;
	image = new Pixel*[numLEDS];
	for (int col = 0; col < numLEDS; col++) {
		image[col] = new Pixel[frameCount];
	}
	for (int i = 0; i < numLEDS; i++) {
		for (int j = 0; j < frameCount; j++) {
			image[i][j] = origImage.image[i][j];
		}
	}
}
Image::~Image() { //destructor
	for (int i = 0; i < numLEDS; i++) {
			delete[] image[i];
	}
	delete[] image;
	image = nullptr;
	numLEDS = 0; frameCount = 0; 
}
Image& Image::operator=(const Image& objectToCopy) { //copy assignment constructor
	// delete old data
	// allocate new memory
	// copy data
	if (this != &objectToCopy) { // check for self assignment
		for (int i = 0; i < numLEDS; i++) { // delete old data
			delete[] image[i];
		}
		delete[] image;
		numLEDS = objectToCopy.numLEDS;
		frameCount = objectToCopy.frameCount;
		image = new Pixel*[numLEDS]; // allocate new memory
		for (int col = 0; col < numLEDS; col++) {
			image[col] = new Pixel[frameCount];
		}
		for (int i = 0; i < numLEDS; i++) { // copy data
			for (int j = 0; j < frameCount; j++) {
				image[i][j] = objectToCopy.image[i][j];
			}
		}
	}
	return *this;
}	

Pixel*& Image::operator[](int column) { return image[column]; }

const Pixel* Image::operator[](int column) const { return image[column]; }

int Image::getNumLEDS() { return numLEDS; }

int Image::getFrameCount() { return frameCount; }
	

void Image::output(string filename) {
  cout << "Outputting image..." << endl;
  // declare/define and open output file stream
  if (filename.find(".txt") != std::string::npos) {}
  else {
	if (filename.find('.')) {
		stringstream ss(filename);
		string file;
		getline(ss, file, '.');
		filename = (file + ".txt");
	}
	else {
		filename = (filename + ".txt");
	}
  }
  ofstream ofs (filename);
  
  // check if output stream opened successfully
  if (!ofs.is_open()) {
    cout << "Error: failed to open output file " << filename << endl;
    return;
  }
  
  // output preamble
  ofs << "2," << frameCount << endl;
  
  // output pixels
  
// 7 DEVICES, TOTAL LEDS FOR EACH DEVICE, 6 semicolons
int KEYBOARD = 109,STRIP = 170,MOUSE = 16, MPAD = 16,HEADSET = 2,EXTRA = 20, GENERAL = 5; //338 total
  for (int row = 0; row < frameCount; ++row) {
    for (int col = 0; col < KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
      (col != KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }
	for (int col = KEYBOARD; col < STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
      (col != STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }

	for (int col = STRIP+KEYBOARD; col < MOUSE+STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
      (col != MOUSE+STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }

	for (int col = MOUSE+STRIP+KEYBOARD; col < MPAD+MOUSE+STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
      (col != MPAD+MOUSE+STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }

	for (int col = MPAD+MOUSE+STRIP+KEYBOARD; col < HEADSET+MPAD+MOUSE+STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
      (col != HEADSET+MPAD+MOUSE+STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }
	
	for (int col = HEADSET+MPAD+MOUSE+STRIP+KEYBOARD; col < EXTRA+HEADSET+MPAD+MOUSE+STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
	  (col != EXTRA+HEADSET+MPAD+MOUSE+STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << ';');
    }

	for (int col = EXTRA+HEADSET+MPAD+MOUSE+STRIP+KEYBOARD; col < GENERAL+EXTRA+HEADSET+MPAD+MOUSE+STRIP+KEYBOARD; ++col) {
      ofs << image[col][row].getRed() << ',';
      ofs << image[col][row].getGreen() << ',';
	  (col != GENERAL+EXTRA+HEADSET+MPAD+MOUSE+STRIP+KEYBOARD-1) ? (ofs << image[col][row].getBlue() << ',') :
		(ofs << image[col][row].getBlue() << '\n');
    }
	
  }
}

// note: if have any 'b' values must change last one to 0 next to ';'
void Image::fillColor(Pixel p,int startCol, int endCol, int startRow, int endRow) {
	if (endRow > frameCount || endRow <= 0) {
		(throw std::invalid_argument("Error: Invalid frame selection"));  
		}
	if (startRow > frameCount || startRow <= 0 || startRow > endRow) {
		(throw std::invalid_argument("Error: Invalid frame selection")); 
		}
		
	if (startCol < 0 || startCol > endCol) {
		(throw std::invalid_argument("Error: Invalid set of keys to be colored")); 
		}
	if (endCol < 0) {
		(throw std::invalid_argument("Error: Invalid set of keys to be colored")); 
		}
	for (int row = startRow-1; row < endRow; ++row) {
      for (int col = startCol; col < endCol; ++col) {
			image[col][row].setRed(p.getRed());
			image[col][row].setGreen(p.getGreen());
	// Due to semicolon bug, last key on devices must be set to no color or import to website fails
		if (col == 108 || col == 278 || col == 294 || col == 310 || col == 312 || col == 332 || col == 337) {
			//image[col][row].setRed(0);
			//image[col][row].setGreen(0);
			image[col][row].setBlue(0);
			}
		else {
			image[col][row].setBlue(p.getBlue());
		}
			// cout << "Set image[" << col << "][" << row << "] " << image[col][row] << endl;
		}
    }
	cout << "Successfully filled in image with RGB color" << endl;
}


