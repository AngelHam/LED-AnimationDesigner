
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>
#include "LedRGBColorMaker.h"

void printMenu();

std::string getFilename(std::string prompt);

unsigned int getColorValue(std::string prompt);

Pixel getPixel();

void getBounds(Image& image, int bounds[]);

void processLoad(Image& image);

void processNew(Image& image);

void processAdd(const Image& image);

void processHelp();
  
#endif