#ifndef LEDRGBCOLORMAKER_H
#define LEDRGBCOLORMAKER_H

#include <string>
#include "Pixel.h"

class Image {
	Pixel** image;
	int numLEDS; // columns
	int frameCount; // rows
	std::string filename;
private:
	void readInFile(std::string filename);
	void allocateImage(int numLEDS,int frameCount);
	void clear();
	void print();
	
public: 
	Image();
	Image(std::string filename);
	Image(int frames);
	
	Image(const Image& origImage); //copy constructor
	~Image(); //destructor
	Image& operator=(const Image& objectToCopy); // copy assignment operator	
	
	Pixel*& operator[](int column);
	const Pixel* operator[](int column) const;
	int getNumLEDS();
	int getFrameCount();

	void output(std::string filename);
	void fillColor(Pixel p,int startCol, int endCol, int startRow, int endRow); 

};


#endif